package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.PlamingGo.dao.JoinDao;
import com.tech.PlamingGo.dto.JoinDto;

@Controller
public class JoinController {
	
	//SqlSession
	//@AutoWired : 각 상황에 타입에 맞는 loC컨테이너 안에 존재하는 Bean 자동 주입
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/join")
	public String join() {
		System.out.println("회원가입 뷰단");
		return "join";
	}
	
	@RequestMapping("/register")
	public String reg(Model model, HttpServletRequest request) {
		System.out.println("회원가입 기능실행");
		String user_id = request.getParameter("user_id");
		String user_pw = request.getParameter("user_pw");
		String user_email = request.getParameter("user_email");
		String user_name = request.getParameter("user_name");
		String user_birth = request.getParameter("user_birth");
		String user_phone = request.getParameter("user_phone");
		int user_gender = Integer.parseInt(request.getParameter("user_gender"));
	
		
		JoinDao dao = sqlSession.getMapper(JoinDao.class);
		dao.register(user_id, user_pw, user_email, user_name, user_birth, user_gender, user_phone);
	return "redirect:login_view";
		
	}

}
