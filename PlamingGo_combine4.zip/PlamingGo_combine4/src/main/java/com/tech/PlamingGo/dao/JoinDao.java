package com.tech.PlamingGo.dao;

import com.tech.PlamingGo.dto.JoinDto;

public interface JoinDao {


	int logstatus(int a);

		
	
	
	public void register(
			String user_id,
			String user_pw,
			String user_email,
			String user_name,
			String user_birth,
			int user_gender,
			String user_phone
			);
	public JoinDto login(
			String login_Id,
			String login_pw
			);




	




}


