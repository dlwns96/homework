package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.DramaDto;

public interface DramaDao {
	
	public ArrayList<DramaDto> drama(int start, int end);	// 리스트
	public DramaDto drama_detailview(String code); 			// 상세보기
	public int selectDramaCount();							// 페이징 처리 中 전체 드라마 데이터 개수(totDrama)알아내기
	public void upHit(String code);							// 조회수 증가
	
	
	
}
