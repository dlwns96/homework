package com.tech.PlamingGo.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MypageController {

	
	
	@RequestMapping("/mypage")
	public String mypage() {
		
		
		
		return "mypage/mypage";
		
	}
	
	@RequestMapping("/mypage_out_terms")
	public String mypage_out_terms() {
		
		return "mypage/mypage_out_terms";
	}
	
	@RequestMapping("/mypage_out")
	public String mypage_out() {
		
		return "mypage/mypage_out";
	}
	
	@RequestMapping("/out_check")
	public String out_check(HttpServletRequest request, Model model) throws Exception {
		System.out.println("로그인 기능시작");	
		String login_id = request.getParameter("login_id");
		String login_pw = request.getParameter("login_pw");
		
		String sql1="SELECT USER_PASS FROM PG_USER WHERE USER_ID=?";
		String sql2="DELETE FROM PG_USER WHERE USER_ID=?";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//접속
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String user="scott";
		String pw="123456";
		Connection con=DriverManager.getConnection(url,user,pw);
		System.out.println("db에 접속했음");
		//실행
		PreparedStatement pstmt1=con.prepareStatement(sql1);
		pstmt1.setString(1, login_id);
		ResultSet rs= pstmt1.executeQuery();//select 실행
		System.out.println(login_id+","+login_pw);
		System.out.println("sql문으로 검증시작");
		String insertpass="";
		int x=-1;
		String msg="";
		if(rs.next()){
			insertpass=rs.getString("user_pass");
			System.out.println(insertpass);
			if(insertpass.equals(login_pw)) {
				System.out.println("아디비번 일치");
				x=1; 
				
			}else{//pass불일치
				System.out.println("비번 불일치");
				x=0;
			}
		}else{//아이디가 존재하지 않은상태
			System.out.println("존재하지않는 아이디");
			x=2;
		}

		
		if(x==1){
			PreparedStatement pstmt2 = con.prepareStatement(sql2);
			pstmt2.setString(1, login_id);
			pstmt2.executeQuery();
			request.getSession().setAttribute("id", login_id);
			System.out.println("삭제한 아이디 : "+(String)request.getSession().getAttribute("id"));
			System.out.println("삭제성공 확인메세지창으로감");
			request.getSession().invalidate();
			return "mypage/out_complete";
		}else if(x==0){
			request.getSession().removeAttribute("log");
			request.getSession().setAttribute("log", x);
			System.out.println((Integer)request.getSession().getAttribute("log"));
			return "redirect:mypage_out";
		}else if(x==2){
			request.getSession().removeAttribute("log");
			request.getSession().setAttribute("log", x);
			System.out.println((Integer)request.getSession().getAttribute("log"));
			return "redirect:mypage_out";
		}else {
			return "redirect:mypage_out";
		}
		
		
		
	}
	
	public String out(HttpServletRequest request) {
		
		
		return "mypage/out_complete";
	}
	

}
